#!/usr/bin/env bash
# ==============================================================================
# EdgeProxy Client Bootstrap & Installation Script
# File: /opt/edgeproxy/client/install.sh
# ==============================================================================
set -euo pipefail

echo "[INFO] Loading EdgeProxy Client precompiled container image..."
if [ -f "/opt/edgeproxy/client/image.tar" ]; then
    podman load -i /opt/edgeproxy/client/image.tar
else
    echo "[ERROR] Image archive /opt/edgeproxy/client/image.tar not found!" >&2
    exit 1
fi

echo "[INFO] Reloading systemd daemon to recognize Quadlet..."
systemctl daemon-reload

echo "[INFO] Enabling and starting edgeproxy-client.service..."
systemctl enable --now edgeproxy-client.service

echo "[SUCCESS] EdgeProxy Client installed and started successfully!"
