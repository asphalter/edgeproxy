#!/bin/bash
# ==============================================================================
# EdgeProxy Client Zero-Touch Sync Agent
# Automatically syncs client.toml from Manager VPS and notifies Rathole
# ==============================================================================
set -euo pipefail

DEST_FILE="${DEST_FILE:-/opt/edgeproxy/client/rathole/client.toml}"
SERVER_URL="${SERVER_URL:-https://auth.edge.mpv.cx}"
SYNC_TOKEN="${SYNC_TOKEN:-}"
INTERVAL="${INTERVAL:-20}"

# Parse CLI arguments
INSTALL_SYSTEMD=false
while [[ $# -gt 0 ]]; do
  case "$1" in
    --token)
      SYNC_TOKEN="$2"
      shift 2
      ;;
    --url)
      SERVER_URL="$2"
      shift 2
      ;;
    --dest)
      DEST_FILE="$2"
      shift 2
      ;;
    --interval)
      INTERVAL="$2"
      shift 2
      ;;
    --install-systemd)
      INSTALL_SYSTEMD=true
      shift
      ;;
    *)
      shift
      ;;
  esac
done

if [[ -z "$SYNC_TOKEN" ]]; then
  echo "Error: specify token with --token <SYNC_TOKEN> or via environment variable SYNC_TOKEN." >&2
  exit 1
fi

mkdir -p "$(dirname "$DEST_FILE")"

sync_once() {
  local tmp_file="${DEST_FILE}.tmp"
  local http_code

  http_code=$(curl -sS -k -w "%{http_code}" -H "Authorization: Bearer ${SYNC_TOKEN}" "${SERVER_URL}/api/v1/client/config" -o "$tmp_file" || echo "000")

  if [[ "$http_code" == "200" ]]; then
    # Verify that content is a valid non-empty TOML containing [client]
    if grep -q "\[client\]" "$tmp_file"; then
      if ! cmp -s "$tmp_file" "$DEST_FILE"; then
        mv "$tmp_file" "$DEST_FILE"
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] [sync-agent] client.toml updated successfully."

        # Notify Rathole to reload configuration if running
        if command -v systemctl >/dev/null 2>&1 && systemctl is-active --quiet rathole-client; then
          echo "[$(date '+%Y-%m-%d %H:%M:%S')] [sync-agent] Restarting rathole-client service..."
          systemctl restart rathole-client || true
        elif command -v podman >/dev/null 2>&1 && podman ps -q --filter name=edgeproxy-client | grep -q .; then
          echo "[$(date '+%Y-%m-%d %H:%M:%S')] [sync-agent] Restarting container edgeproxy-client..."
          podman restart edgeproxy-client || true
        fi
        return 0
      else
        rm -f "$tmp_file"
        return 1
      fi
    else
      echo "[$(date '+%Y-%m-%d %H:%M:%S')] [sync-agent] Warning: received payload does not contain [client] section. Discarded." >&2
      rm -f "$tmp_file"
      return 2
    fi
  else
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [sync-agent] Synchronization failed (HTTP ${http_code}) from ${SERVER_URL}." >&2
    rm -f "$tmp_file"
    return 2
  fi
}

send_heartbeat_and_logs() {
  if [[ -z "$SYNC_TOKEN" ]]; then
    return 0
  fi

  local client_name
  client_name="${CLIENT_NAME:-$(hostname 2>/dev/null || echo "edgeproxy-sync-agent")}"

  local hname
  hname=$(hostname 2>/dev/null || echo "$client_name")

  local uptime_sec=0
  if [[ -f /proc/uptime ]]; then
    uptime_sec=$(cut -d. -f1 /proc/uptime 2>/dev/null || echo 0)
  fi

  local rathole_ver="unknown"
  if command -v rathole >/dev/null 2>&1; then
    rathole_ver=$(rathole --version 2>&1 | head -n1 || echo "unknown")
  fi

  local raw_logs=""
  if command -v podman >/dev/null 2>&1; then
    raw_logs=$(podman logs --tail 30 edgeproxy-client 2>&1 || true)
  fi
  if [[ -z "$raw_logs" ]] && command -v journalctl >/dev/null 2>&1; then
    raw_logs=$(journalctl -u edgeproxy-client -n 30 --no-pager 2>&1 || true)
  fi

  local json_payload=""
  if command -v python3 >/dev/null 2>&1; then
    json_payload=$(python3 -c '
import sys, json

client_name = sys.argv[1]
uptime_sec = int(sys.argv[2])
version = sys.argv[3]
hname = sys.argv[4]
raw_logs = sys.stdin.read()

logs = []
for line in raw_logs.splitlines():
    l = line.strip()
    if not l:
        continue
    lvl = "info"
    if "ERROR" in l or "error" in l:
        lvl = "error"
    elif "WARN" in l or "warn" in l:
        lvl = "warn"
    logs.append({"level": lvl, "message": l})

payload = {
    "client_name": client_name,
    "uptime_seconds": uptime_sec,
    "version": version,
    "hostname": hname,
    "logs": logs[-30:]
}
print(json.dumps(payload))
' "$client_name" "$uptime_sec" "$rathole_ver" "$hname" <<< "$raw_logs" 2>/dev/null || true)
  fi

  if [[ -z "$json_payload" ]]; then
    json_payload="{\"client_name\": \"$client_name\", \"uptime_seconds\": $uptime_sec, \"version\": \"$rathole_ver\", \"hostname\": \"$hname\", \"logs\": []}"
  fi

  curl -sS -k -X POST \
    -H "Content-Type: application/json" \
    -H "Authorization: Bearer ${SYNC_TOKEN}" \
    -d "$json_payload" \
    "${SERVER_URL}/api/v1/client/telemetry" >/dev/null 2>&1 || true
}

if [ "$INSTALL_SYSTEMD" = true ]; then
  SERVICE_NAME="edgeproxy-sync"
  SERVICE_PATH="/etc/systemd/system/${SERVICE_NAME}.service"

  SCRIPT_INSTALL_PATH="/usr/local/bin/edgeproxy-sync.sh"
  cp "$0" "$SCRIPT_INSTALL_PATH"
  chmod +x "$SCRIPT_INSTALL_PATH"

  echo "Installing systemd service in ${SERVICE_PATH}..."
  cat <<EOF > "$SERVICE_PATH"
[Unit]
Description=EdgeProxy Client Zero-Touch Sync Agent
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=${SCRIPT_INSTALL_PATH} --token "${SYNC_TOKEN}" --url "${SERVER_URL}" --dest "${DEST_FILE}" --interval "${INTERVAL}"
Restart=always
RestartSec=10s
User=root

[Install]
WantedBy=multi-user.target
EOF

  systemctl daemon-reload
  systemctl enable --now "$SERVICE_NAME"
  echo "Service ${SERVICE_NAME} enabled and started successfully."
  exit 0
fi

echo "=================================================================="
echo "EdgeProxy Zero-Touch Sync Agent"
echo "Target URL: ${SERVER_URL}"
echo "Dest File : ${DEST_FILE}"
echo "Interval  : ${INTERVAL}s"
echo "=================================================================="

# Initial sync
sync_once || true
send_heartbeat_and_logs || true

while true; do
  sleep "$INTERVAL"
  sync_once || true
  send_heartbeat_and_logs || true
done
